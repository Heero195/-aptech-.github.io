# Ancient Empires 2 Revolution Mod (AE2RM) games download

## Update logs from original homepage
[**Update logs**](https://web.archive.org/web/20201110233517/http://projectd8.org/Ancient_Empires_II_RM)

## Currently available versions

### Version 2.5
* [Download JAR](2.5/AncientEmpiresIIRM.jar)

### Version 2.4
* [Download JAR (English version)](2.4/AncientEmpiresIIRMEn.jar)
* [Download JAR (Russian version)](2.4/AncientEmpiresIIRMRu.jar)