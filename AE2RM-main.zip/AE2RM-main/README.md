# AE2RM
**Ancient Empires 2 Revolution Mod (AE2RM)**: game download & source code.

* [**Project main page**](https://web.archive.org/web/20201110233517/http://projectd8.org/Ancient_Empires_II_RM)
* [Download games (`jar` directory)](jar/)
* [Source code (`src` directory)](src/)